/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int main()
{
    int p, q, r;
	printf("Enter the value of p, q and r: ");
    scanf("%d %d %d", &p, &q, &r);
	for (int i = p; i <= q; i++) 
	{
        if (i % 10 == r)
        {
            continue;
        }
        printf("%d ", i);
    }
return 0;
}