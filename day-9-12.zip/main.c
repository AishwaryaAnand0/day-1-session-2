/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() 
{
    int age;
    printf("Enter your age: ");
    scanf("%d", &age);
    if (age >= 18) 
    {
        printf("You are eligible to vote.\n");
    } 
    else 
    {
        int years_left = 18 - age;
        printf("You are not eligible to vote.\n");
        printf("You need to wait %d more years to vote.\n", years_left);
    }
    return 0;
}
