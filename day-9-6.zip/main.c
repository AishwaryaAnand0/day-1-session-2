/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
double power(double x, double n) {
    return pow(x, n);
}
double add(double x, double n) {
    return x + n;
}
double subtract(double x, double n) {
    return x - n;
}
double multiply(double x, double n) {
    return x * n;
}
double divide(double x, double n) {
    return x / n;
}
int main() {
    double x, n, result;
    int choice;

    printf("Enter two operands: ");
    scanf("%lf %lf", &x, &n);

    printf("Choose an operation:\n");
    printf("1. Power\n");
    printf("2. Add\n");
    printf("3. Subtract\n");
    printf("4. Multiply\n");
    printf("5. Divide\n");
    scanf("%d", &choice);

    switch (choice) {
        case 1:
            result = power(x, n);
            printf("%.2lf to the power of %.2lf is %.2lf\n", x, n, result);
            break;
        case 2:
            result = add(x, n);
            printf("%.2lf + %.2lf = %.2lf\n", x, n, result);
            break;
        case 3:
            result = subtract(x, n);
            printf("%.2lf - %.2lf = %.2lf\n", x, n, result);
            break;
        case 4:
            result = multiply(x, n);
            printf("%.2lf * %.2lf = %.2lf\n", x, n, result);
            break;
        case 5:
            result = divide(x, n);
            printf("%.2lf / %.2lf = %.2lf\n", x, n, result);
            break;
        default:
            printf("Invalid choice!\n");
    }

    return 0;
}

