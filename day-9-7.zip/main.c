/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int num, n= 0,r;
    printf("Enter an integer: ");
    scanf("%d", &num);
    while (num != 0) 
    {
        r = num % 10;
        n= n * 10 +r;
        num /= 10;
    }
    printf("Reversed number = %d\n",n);
    return 0;
}
